CREATE PROCEDURE Table_Partition_By_Month(IN create_table_name VARCHAR(50))
  begin
	DECLARE database_name VARCHAR(50);
	/*当前分区的日期*/
	DECLARE cur_partition_date VARCHAR(20);
	/*下一个分区日期*/
	DECLARE next_partition_date DATE;
	/*最大分区日期*/
	DECLARE max_partition_date DATE;
	
	/*启动事务*/
	declare exit handler for sqlexception rollback;
    start TRANSACTION;
	
	/* 获取当前数据库名*/
	select database() into database_name;
	
	/*获取已经存在分区的日期*/
    select REPLACE(partition_name,'P','') into cur_partition_date from INFORMATION_SCHEMA.PARTITIONS where TABLE_SCHEMA=database_name and table_name=create_table_name order by partition_ordinal_position DESC limit 1;
		
		set cur_partition_date = CONCAT(cur_partition_date,'01');

		/* 计算下一个分区日期*/
		set next_partition_date = DATE(DATE_ADD(cur_partition_date, INTERVAL 1 MONTH));
		/* 计算最大分区日期*/
		set max_partition_date = DATE(DATE_ADD(DATE(CONCAT(left(CURDATE()+0, 6), '01'))+0, INTERVAL 1 MONTH));
		/*创建分区，一直到当前月份的下一个分区*/
	while (next_partition_date <= max_partition_date) do
		set @cur_partition_name = left(date(next_partition_date)+0, 6);
		set @than_date = DATE(DATE_ADD(DATE(next_partition_date)+0, INTERVAL 1 MONTH));
		SET @execute_sql=CONCAT('ALTER TABLE ',create_table_name,' ADD PARTITION (PARTITION P',@cur_partition_name,' VALUES LESS THAN (TO_DAYS ('',date(@than_date),'')))');
		PREPARE stmt2 FROM @execute_sql;
		EXECUTE stmt2;
		DEALLOCATE PREPARE stmt2;
		set next_partition_date = DATE(DATE_ADD(DATE(next_partition_date)+0, INTERVAL 1 MONTH));
	end while;
	
	/*提交事务*/
	COMMIT ;
end;
